CREATE VIEW cid3 AS
  SELECT `leyou`.`tb_category`.`parent_id` AS `parent_id`
  FROM `leyou`.`tb_category`
  GROUP BY `leyou`.`tb_category`.`parent_id`;
